Fake News dataset from https://www.kaggle.com/datasets/hassanamin/textdb3?resource=download.
